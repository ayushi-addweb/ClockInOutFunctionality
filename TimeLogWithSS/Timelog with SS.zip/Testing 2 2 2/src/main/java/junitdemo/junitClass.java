package junitdemo;

public class junitClass
{
    public int add(int a, int b)
    {
        return a + b;
    }
}
