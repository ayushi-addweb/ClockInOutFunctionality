package junitdemo;

import org.bson.assertions.Assertions;

public class junitClassTest
{
    private final junitClass abjunitclass = new junitClass();

    public void testAddition()
    {
        

    }
}
