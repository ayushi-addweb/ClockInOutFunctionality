package TestRunner;

import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = {"/Users/addweb/Downloads/Testing/src/test/java/Feature"},
        glue = {"Steps"},
        plugin = {"html:/Users/addweb/Desktop/Report/Timelog"}
)

public class TestRunner
{

}
